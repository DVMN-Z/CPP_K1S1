#pragma once
void select_Lab(int lab);